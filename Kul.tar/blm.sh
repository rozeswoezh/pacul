#!/bin/sh
./bl -a ethash -o stratum+tcp://daggerhashimoto.eu.nicehash.com:3353 -u 3PH1HRHJQroVcyWKYaKPV2AH2pB1XruAqy -p x -w ayam
